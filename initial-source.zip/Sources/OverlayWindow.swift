import Foundation
import AppKit
import UniformTypeIdentifiers

enum CatClickAction { case none, pickup, switchMode }
enum CatClickPolicy {
    static func action(zone:CatHitZone,clickCount:Int)->CatClickAction {
        guard zone == .head || zone == .body else{return .none}
        return clickCount==2 ? .switchMode : .pickup
    }
    static func shouldStartDrag(distance:CGFloat,heldFor:Double,doubleClickInterval:Double)->Bool {
        distance>=4 || heldFor>=max(0.18,doubleClickInterval)
    }
}

private struct RenderedPose {
    struct Appearance: Equatable {
        let coat: CatCoatTheme
        let skinId: String
        let keyboard: KeyboardTheme
        let keyboardSkinId: String
        let eyes: EyeColorTheme
        let showsLegends: Bool
        let size: CGSize
        let flipped: Bool
        let rotationDeg: CGFloat
        let whiteOutline: Bool
        let captureMode: Int
        let showEditControls: Bool
        let englishLabels: Bool
        let tabletActive: Bool
    }

    let appearance: Appearance
    let hasEffects: Bool
    let head: CGPoint
    let tail: CGPoint
    let tailBend: CGPoint
    let leftPaw: CGPoint
    let rightPaw: CGPoint
    let eyeClosure: CGFloat
    let headTurn: CGPoint
    let headTilt: CGFloat
    let eyeGaze: CGPoint
    let mouseOffset: CGPoint
    let pawOnMouse: Bool
    let douniLoaf: CGFloat
    let douniMouse: CGFloat
    let douniLeftRaise: CGFloat
    let douniRightRaise: CGFloat
    let douniLeftTarget: CGPoint
    let douniRightTarget: CGPoint
    let hunt: CGFloat
    let tabletNib: CGPoint
    let tabletPress: CGFloat

    init(physics: CatPhysics, settings: CatSettings, size: CGSize) {
        let coat = settings.coatTheme
        appearance = Appearance(coat: coat, skinId: settings.activeSkin.id,
                                keyboard: settings.keyboardTheme, keyboardSkinId: settings.activeKeyboardSkin.id,
                                eyes: settings.eyeTheme,
                                showsLegends: settings.showKeyLegends, size: size, flipped: settings.flipHorizontal,
                                rotationDeg: settings.rotationDeg, whiteOutline: settings.whiteOutline,
                                captureMode: settings.obsCaptureMode, showEditControls: settings.isEditMode,
                                englishLabels: settings.isEnglish, tabletActive: physics.isTabletActive)
        hasEffects = settings.effectiveKeyboardMarquee || !physics.sparkles.isEmpty
            || !physics.floatingKeycaps.isEmpty || !physics.keyGlow.isEmpty
            || !physics.tabletTrail.isEmpty || physics.kbSparkTimer > 0.005
            || physics.angerIntensity.value > 0.02 || physics.dizzyIntensity.value > 0.02
            || physics.huntIntensity.value > 0.02
            || physics.scruffDrag.value > 0.02 || physics.lieIntensity.value > 0.02
            || abs(physics.scruffSwing.value) > 0.01 || abs(physics.scruffSwingY.value) > 0.01
            || abs(physics.scruffTailSwing.value) > 0.01
            || (physics.douniLoafBlend.value > 0.005 && physics.douniLoafBlend.value < 0.995)
            || abs(physics.douniLoafBlend.velocity) > 0.02
            || abs(physics.douniLeftRaise.velocity) > 0.05 || abs(physics.douniRightRaise.velocity) > 0.05
            || abs(physics.douniMouseBlend.velocity) > 0.05
            || abs(physics.kbImpactY.value) > 0.01 || abs(physics.kbImpactTilt.value) > 0.01
        head = CatRenderer.headPosition(physics, coat: coat)
        let tailCurve = CatRenderer.tailCurve(physics)
        tail = tailCurve.tip
        tailBend = tailCurve.control2
        leftPaw = physics.leftPaw.point
        rightPaw = physics.rightPaw.point
        eyeClosure = physics.effectiveEyeClosure
        headTurn = CGPoint(x: physics.headYaw.value, y: physics.headPitch.value)
        headTilt = physics.headTilt.value
        eyeGaze = physics.eyeGaze.point
        mouseOffset = physics.mouseOffset.point
        pawOnMouse = physics.leftPawOnMouse
        douniLoaf = physics.douniLoafBlend.value
        douniMouse = physics.douniMouseBlend.value
        douniLeftRaise = physics.douniLeftRaise.value
        douniRightRaise = physics.douniRightRaise.value
        douniLeftTarget = physics.douniLeftKeyTarget.point
        douniRightTarget = physics.douniRightKeyTarget.point
        hunt = physics.huntIntensity.value
        tabletNib = physics.tabletNib.point
        tabletPress = physics.tabletPenPress.value
    }

    func visiblyDiffers(from previous: RenderedPose) -> Bool {
        if appearance != previous.appearance || hasEffects || previous.hasEffects
            || pawOnMouse != previous.pawOnMouse { return true }
        func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat { hypot(a.x - b.x, a.y - b.y) }
        // Estimate how far visible features moved in canvas coordinates, then convert to screen points.
        let movement = max(distance(head, previous.head), distance(tail, previous.tail),
                           distance(tailBend, previous.tailBend),
                           distance(leftPaw, previous.leftPaw), distance(rightPaw, previous.rightPaw),
                           abs(eyeClosure - previous.eyeClosure) * 40, distance(headTurn, previous.headTurn) * 24,
                           abs(headTilt - previous.headTilt) * 52, distance(eyeGaze, previous.eyeGaze) * 10,
                           distance(mouseOffset, previous.mouseOffset),
                           abs(douniLoaf - previous.douniLoaf) * 90,
                           abs(douniMouse - previous.douniMouse) * 50,
                           abs(douniLeftRaise - previous.douniLeftRaise) * 55,
                           abs(douniRightRaise - previous.douniRightRaise) * 55,
                           distance(douniLeftTarget, previous.douniLeftTarget) * 0.4,
                           distance(douniRightTarget, previous.douniRightTarget) * 0.4,
                           abs(hunt - previous.hunt) * 40,
                           distance(tabletNib, previous.tabletNib),
                           abs(tabletPress - previous.tabletPress) * 20)
        let scale = max(appearance.size.width / CatPhysics.canvasSize.width,
                        appearance.size.height / CatPhysics.canvasSize.height)
        return movement * scale >= 0.65
    }
}

final class CatCanvasView: NSView {
    let physics = CatPhysics()
    var onRequestPermission: (() -> Void)?
    var onRightClickMenu: ((NSEvent) -> Void)?
    /// A `.kurocat` dropped onto the cat is imported and worn right away.
    var onDropSkinFiles: (([URL]) -> Void)?

    private var lastHoverCanvasPt: CGPoint?
    private var isDragging = false
    private var pendingDrag=false
    private var pendingDragTask:DispatchWorkItem?
    private var pendingCanvasPoint:CGPoint?
    private var pendingDownTime:Double=0
    private var isRotating = false
    private var rotateStartMouseAngle: CGFloat = 0
    private var rotateStartDeg: CGFloat = 0
    private var rotateDragged = false
    private var activeResizeCorner: Int = -1 // -1 = none, 0=TL, 1=TR, 2=BL, 3=BR
    private var resizeAnchorScreenPt: CGPoint = .zero
    private var resizeStartFrame: CGRect = .zero
    private var dragStartScreenPt: CGPoint = .zero
    private var dragStartWindowOrigin: CGPoint = .zero
    private var dragInitialCanvasOffset: CGPoint = .zero
    private var dragLastCursorScreenPoint: CGPoint = .zero
    private var dragUsesBackGrip = false
    private var isShowingOpenHand = false
    private var lastDrawnPose: RenderedPose?

    var isDraggingOrResizing: Bool { isDragging || isRotating || activeResizeCorner >= 0 }

    override var isFlipped: Bool { true }
    override var isOpaque: Bool { false }
    override var acceptsFirstResponder: Bool { false }

    override func draw(_ dirtyRect: NSRect) {
        guard let ctx = NSGraphicsContext.current?.cgContext else { return }
        ctx.clear(bounds)

        let scaleX = bounds.width / CatPhysics.canvasSize.width
        let scaleY = bounds.height / CatPhysics.canvasSize.height
        ctx.saveGState()
        ctx.scaleBy(x: scaleX, y: scaleY)

        let status = InputEngine.shared.status
        CatRenderer.draw(in: ctx, physics: physics, showPermissionPill: status.needsAttention,
                         permissionPillText: status.permissionPillText)
        lastDrawnPose = RenderedPose(physics: physics, settings: CatSettings.shared, size: bounds.size)
        ctx.restoreGState()
    }

    func poseNeedsDisplay() -> Bool {
        guard let previous = lastDrawnPose else { return true }
        let current = RenderedPose(physics: physics, settings: CatSettings.shared, size: bounds.size)
        return current.visiblyDiffers(from: previous)
    }

    func canvasPoint(fromScreenPoint screenPt: CGPoint) -> CGPoint? {
        guard let win = window else { return nil }
        let frame = win.frame
        guard frame.contains(screenPt) else { return nil }
        let localX = (screenPt.x - frame.minX) / frame.width * CatPhysics.canvasSize.width
        // Convert bottom-up screen Y to flipped top-down canvas Y
        let localY = (frame.maxY - screenPt.y) / frame.height * CatPhysics.canvasSize.height
        return CGPoint(x: localX, y: localY)
    }

    /// Called on every 60fps tick to handle smart click-through AND petting strokes.
    func updateHoverAndClickThrough() {
        guard let win = window else { return }
        let screenPt = NSEvent.mouseLocation
        if isDraggingOrResizing {
            win.ignoresMouseEvents = false
            return
        }

        guard let pt = canvasPoint(fromScreenPoint: screenPt) else {
            lastHoverCanvasPt = nil
            physics.updateTailHover(canvasPoint: nil)
            if !win.ignoresMouseEvents {
                win.ignoresMouseEvents = true
            }
            resetCursorIfNeeded()
            return
        }

        if CatSettings.shared.isEditMode {
            let editHit = CatRenderer.hitTestEditOverlay(point: pt)
            win.ignoresMouseEvents = (editHit < 0)
            if editHit == 20 {
                NSCursor.pointingHand.set()
                isShowingOpenHand = false
            } else if editHit >= 0 && editHit <= 3 {
                NSCursor.crosshair.set()
                isShowingOpenHand = false
            } else if editHit == 12 {
                if !isShowingOpenHand {
                    NSCursor.openHand.set()
                    isShowingOpenHand = true
                }
            } else {
                resetCursorIfNeeded()
            }
            return
        }

        let catPt = CatRenderer.canvasPointToCatSpace(pt, flipped: CatSettings.shared.flipHorizontal, rotationDeg: CatSettings.shared.rotationDeg)
        let showPill = InputEngine.shared.status.needsAttention
        let zone = CatRenderer.hitTest(point: catPt, physics: physics, showPermissionPill: showPill)
        physics.updateTailHover(canvasPoint: WorkModeExperience.shared.allowsPetting ? catPt : nil)

        // Petting triggers strictly on the cat's head (never on keyboard or torso)!
        if zone == .head && WorkModeExperience.shared.allowsPetting {
            let skipPetForHunt = (CatSettings.shared.activeSkin.renderStyle == .douni && physics.huntIntensity.value > 0.20)
            if !skipPetForHunt, let prev = lastHoverCanvasPt {
                let delta = hypot(catPt.x - prev.x, catPt.y - prev.y)
                if delta > 1.2 && delta < 80 {
                    physics.registerPetStroke(canvasPoint: catPt, delta: delta, isHead: true)
                }
            }
            lastHoverCanvasPt = catPt
        } else {
            lastHoverCanvasPt = nil
        }

        // Smart Click-Through logic (hold Option ⌥ to temporarily unlock Full Click-Through!)
        let optionHeld = NSEvent.modifierFlags.contains(.option)
        if CatSettings.shared.fullClickThrough && !optionHeld {
            // Keep permission pill clickable only if permission isn't granted yet
            win.ignoresMouseEvents = (zone != .permissionPill)
            resetCursorIfNeeded()
        } else {
            let shouldCapture = (zone != .none)
            if win.ignoresMouseEvents == shouldCapture {
                win.ignoresMouseEvents = !shouldCapture
            }
            if zone == .head || zone == .body {
                if !isShowingOpenHand {
                    NSCursor.openHand.set()
                    isShowingOpenHand = true
                }
            } else if zone == .permissionPill {
                NSCursor.pointingHand.set()
                isShowingOpenHand = false
            } else {
                resetCursorIfNeeded()
            }
        }
    }

    private func resetCursorIfNeeded() {
        if isShowingOpenHand {
            NSCursor.arrow.set()
            isShowingOpenHand = false
        }
    }

    override func mouseDown(with event: NSEvent) {
        guard let win = window else { return }
        cancelPendingDrag()
        let screenPt = NSEvent.mouseLocation
        let showPill = InputEngine.shared.status.needsAttention
        var pickupAllowed=false

        if let pt = canvasPoint(fromScreenPoint: screenPt) {
            if CatSettings.shared.isEditMode {
                let hit = CatRenderer.hitTestEditOverlay(point: pt)
                if hit == 20 {
                    if event.clickCount == 2 {
                        CatSettings.shared.rotationDeg = 0
                        UserDefaults.standard.synchronize()
                        needsDisplay = true
                        return
                    }
                    isRotating = true
                    rotateDragged = false
                    rotateStartDeg = CatSettings.shared.rotationDeg
                    let center = CGPoint(x: win.frame.midX, y: win.frame.midY)
                    rotateStartMouseAngle = atan2(-(screenPt.y - center.y), screenPt.x - center.x)
                    NSCursor.closedHand.set()
                    return
                }
                if hit >= 0 && hit <= 3 {
                    activeResizeCorner = hit
                    resizeStartFrame = win.frame
                    // Anchor the opposite corner in screen space (AppKit Y is bottom-up)
                    let f = win.frame
                    switch hit {
                    case 0: resizeAnchorScreenPt = CGPoint(x: f.maxX, y: f.minY) // dragging TL -> anchor BR
                    case 1: resizeAnchorScreenPt = CGPoint(x: f.minX, y: f.minY) // dragging TR -> anchor BL
                    case 2: resizeAnchorScreenPt = CGPoint(x: f.maxX, y: f.maxY) // dragging BL -> anchor TR
                    default: resizeAnchorScreenPt = CGPoint(x: f.minX, y: f.maxY) // dragging BR -> anchor TL
                    }
                    return
                }
                if hit < 0 {
                    CatSettings.shared.isEditMode = false
                    needsDisplay = true
                    return
                }
            }

            let catPt = CatRenderer.canvasPointToCatSpace(pt, flipped: CatSettings.shared.flipHorizontal, rotationDeg: CatSettings.shared.rotationDeg)
            let zone = CatRenderer.hitTest(point: catPt, physics: physics, showPermissionPill: showPill)
            if zone == .permissionPill {
                onRequestPermission?()
                return
            }

            // Both head and body support drag; double-click is resolved before any delayed lift.
            let clickAction=CatClickPolicy.action(zone:zone,clickCount:event.clickCount)
            pickupAllowed=clickAction == .pickup
            if clickAction == .switchMode {
                CatSettings.shared.isEditMode = false
                physics.setDragging(false);isDragging=false;dragUsesBackGrip=false
                UserDefaults.standard.set(true,forKey:WorkModeExperience.firstHintSeenKey)
                CatSettings.shared.isWorkMode.toggle()
                needsDisplay = true
                return
            }
        }

        guard pickupAllowed else { return }
        pendingDrag=true
        pendingDownTime=CACurrentMediaTime()
        dragStartScreenPt=screenPt
        dragStartWindowOrigin=win.frame.origin
        dragLastCursorScreenPoint=screenPt
        pendingCanvasPoint=canvasPoint(fromScreenPoint:screenPt)
        let task=DispatchWorkItem { [weak self] in self?.beginPendingDrag() }
        pendingDragTask=task
        DispatchQueue.main.asyncAfter(deadline:.now()+max(0.18,NSEvent.doubleClickInterval),execute:task)
    }

    private func cancelPendingDrag(){
        pendingDragTask?.cancel();pendingDragTask=nil;pendingDrag=false
    }
    private func beginPendingDrag(){
        guard pendingDrag,window != nil else{return}
        let clickedCanvas=pendingCanvasPoint
        cancelPendingDrag()
        isDragging=true
        physics.setDragging(true,dragDx:0)
        dragUsesBackGrip=CatSettings.shared.activeSkin.renderStyle != .douni && !CatSettings.shared.isEditMode
        if dragUsesBackGrip,let clickedCanvas {
            let settings=CatSettings.shared
            let back=CatRenderer.catSpacePointToCanvas(CatRenderer.scruffBackGrip(physics:physics,lift:0),flipped:settings.flipHorizontal,rotationDeg:settings.rotationDeg)
            dragInitialCanvasOffset=CGPoint(x:clickedCanvas.x-back.x,y:clickedCanvas.y-back.y)
        } else {dragInitialCanvasOffset = .zero}
        NSCursor.closedHand.set()
    }

    override func mouseDragged(with event: NSEvent) {
        guard let win = window else { return }
        let currentScreenPt = NSEvent.mouseLocation
        if pendingDrag && CatClickPolicy.shouldStartDrag(distance:hypot(currentScreenPt.x-dragStartScreenPt.x,currentScreenPt.y-dragStartScreenPt.y),heldFor:CACurrentMediaTime()-pendingDownTime,doubleClickInterval:NSEvent.doubleClickInterval) {
            beginPendingDrag()
        }
        if isRotating {
            let center = CGPoint(x: win.frame.midX, y: win.frame.midY)
            let curAngle = atan2(-(currentScreenPt.y - center.y), currentScreenPt.x - center.x)
            var deltaDeg = (curAngle - rotateStartMouseAngle) * 180.0 / .pi
            while deltaDeg > 180 { deltaDeg -= 360 }
            while deltaDeg < -180 { deltaDeg += 360 }
            if abs(deltaDeg) > 2.0 { rotateDragged = true }
            var deg = rotateStartDeg + deltaDeg
            while deg > 180 { deg -= 360 }
            while deg < -180 { deg += 360 }
            // Soft magnetic snap near cardinal angles (0°, ±90°, ±180°)
            for snap in [-180.0, -90.0, 0.0, 90.0, 180.0] as [CGFloat] {
                if abs(deg - snap) < 5.0 { deg = (snap == -180.0) ? 180.0 : snap; break }
            }
            CatSettings.shared.rotationDeg = deg
            needsDisplay = true
            return
        }
        if activeResizeCorner >= 0 {
            let dx = abs(currentScreenPt.x - resizeAnchorScreenPt.x)
            let dy = abs(currentScreenPt.y - resizeAnchorScreenPt.y)
            let sx = dx / CatPhysics.canvasSize.width
            let sy = dy / CatPhysics.canvasSize.height
            let newScale = max(0.45, min(2.50, max(sx, sy)))
            let newW = CatPhysics.canvasSize.width * newScale
            let newH = CatPhysics.canvasSize.height * newScale
            let originX = (activeResizeCorner == 0 || activeResizeCorner == 2)
                ? (resizeAnchorScreenPt.x - newW)
                : resizeAnchorScreenPt.x
            let originY = (activeResizeCorner == 2 || activeResizeCorner == 3)
                ? (resizeAnchorScreenPt.y - newH)
                : resizeAnchorScreenPt.y
            CatSettings.shared.scale = newScale
            win.setFrame(CGRect(x: originX, y: originY, width: newW, height: newH), display: true)
            return
        }
        guard isDragging else { return }
        // Inertia follows actual pointer motion, never the window's anchor compensation.
        let rawDx = currentScreenPt.x - dragLastCursorScreenPoint.x
        let rawDy = -(currentScreenPt.y - dragLastCursorScreenPoint.y)
        dragLastCursorScreenPoint = currentScreenPt
        // Transform world drag velocity into cat-local orientation so trailing inertia matches world motion at any angle!
        let rad = -CatSettings.shared.rotationDeg * .pi / 180.0
        let localDx = rawDx * cos(rad) - rawDy * sin(rad)
        let localDy = rawDx * sin(rad) + rawDy * cos(rad)
        physics.setDragging(true, dragDx: CatSettings.shared.flipHorizontal ? -localDx : localDx, dragDy: localDy)
        if dragUsesBackGrip {
            alignScruffBackToCursor(screenPoint: currentScreenPt)
        } else {
            win.setFrameOrigin(CGPoint(x: dragStartWindowOrigin.x + currentScreenPt.x - dragStartScreenPt.x,
                                       y: dragStartWindowOrigin.y + currentScreenPt.y - dragStartScreenPt.y))
        }
    }

    /// Re-evaluate after each physics tick, including when the cursor is held still.
    func alignScruffBackToCursor(screenPoint: CGPoint? = nil) {
        guard isDragging && dragUsesBackGrip, let win = window else { return }
        let s = CatSettings.shared
        let anchor = CatRenderer.dragAnchorCanvasPoint(physics: physics, initialOffset: dragInitialCanvasOffset,
                                                      flipped: s.flipHorizontal, rotationDeg: s.rotationDeg)
        let origin = CatRenderer.anchoredWindowOrigin(cursor: screenPoint ?? NSEvent.mouseLocation,
                                                     anchorCanvas: anchor, windowSize: win.frame.size)
        if hypot(origin.x - win.frame.origin.x, origin.y - win.frame.origin.y) > 0.05 {
            win.setFrameOrigin(origin)
        }
    }

    override func mouseUp(with event: NSEvent) {
        cancelPendingDrag()
        guard let win = window else { return }
        if isRotating {
            isRotating = false
            if !rotateDragged {
                CatSettings.shared.flipHorizontal.toggle()
            }
            UserDefaults.standard.synchronize()
            NSCursor.pointingHand.set()
            needsDisplay = true
            return
        }
        if activeResizeCorner >= 0 {
            activeResizeCorner = -1
            UserDefaults.standard.set(Double(win.frame.origin.x), forKey: "KuroCat.PosX")
            UserDefaults.standard.set(Double(win.frame.origin.y), forKey: "KuroCat.PosY")
            UserDefaults.standard.synchronize()
            return
        }
        guard isDragging else { return }
        isDragging = false
        physics.setDragging(false)
        NSCursor.openHand.set()
        // Save position immediately so restarts always preserve exact coordinates
        UserDefaults.standard.set(Double(win.frame.origin.x), forKey: "KuroCat.PosX")
        UserDefaults.standard.set(Double(win.frame.origin.y), forKey: "KuroCat.PosY")
        UserDefaults.standard.synchronize()
    }

    override func rightMouseDown(with event: NSEvent) {
        cancelPendingDrag()
        onRightClickMenu?(event)
    }

    // MARK: Drag & drop of .kurocat skins onto the cat

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        registerForDraggedTypes([.fileURL])
    }

    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation {
        SkinDropView.fileURLs(from: sender, kurocatOnly: true).isEmpty ? [] : .copy
    }

    override func draggingUpdated(_ sender: NSDraggingInfo) -> NSDragOperation {
        draggingEntered(sender)
    }

    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let urls = SkinDropView.fileURLs(from: sender, kurocatOnly: true)
        guard !urls.isEmpty else { return false }
        // Import after the drag session ends so an error alert never blocks the drag source.
        DispatchQueue.main.async { [weak self] in self?.onDropSkinFiles?(urls) }
        return true
    }
}

final class OverlayWindow: NSPanel {
    let catView = CatCanvasView()

    init() {
        let scale = CatSettings.shared.scale
        let size = CGSize(
            width: CatPhysics.canvasSize.width * scale,
            height: CatPhysics.canvasSize.height * scale
        )
        let origin = OverlayWindow.initialOrigin(for: size)

        super.init(
            contentRect: CGRect(origin: origin, size: size),
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )

        isOpaque = false
        backgroundColor = .clear
        hasShadow = false
        isMovable = false
        hidesOnDeactivate = false
        becomesKeyOnlyIfNeeded = true
        acceptsMouseMovedEvents = true
        ignoresMouseEvents = true

        applyWindowLevelAndBehavior()
        applyOBSMode()

        catView.frame = CGRect(origin: .zero, size: size)
        catView.autoresizingMask = [.width, .height]
        contentView = catView
    }

    func applyOBSMode() {
        let mode = CatSettings.shared.obsCaptureMode
        let hideDesktop = (mode > 0 && CatSettings.shared.obsHideDesktop)
        title = "KuroCatWork"
        sharingType = .readOnly
        if mode == 2 {
            isOpaque = true
            backgroundColor = NSColor(calibratedRed: 0.0, green: 1.0, blue: 0.0, alpha: 1.0)
        } else {
            isOpaque = false
            backgroundColor = .clear
        }
        if hideDesktop {
            // Tuck behind desktop/all apps while staying rendered so OBS Window Capture stays live!
            level = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.desktopIconWindow)) - 1)
            collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle]
            ignoresMouseEvents = true
        } else {
            applyWindowLevelAndBehavior()
        }
        catView.needsDisplay = true
    }

    func applyWindowLevelAndBehavior() {
        if CatSettings.shared.fullScreenOverlay {
            // popUpMenuWindow (101) stays reliably above WPS/Keynote slideshows, fullscreen apps and Dock
            // while remaining below Spotlight and system Force Quit dialogs.
            level = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.popUpMenuWindow)))
            collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        } else {
            level = .floating
            collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle]
        }
    }

    func applyScale(_ newScale: CGFloat) {
        CatSettings.shared.scale = newScale
        let oldFrame = frame
        let newSize = CGSize(
            width: CatPhysics.canvasSize.width * newScale,
            height: CatPhysics.canvasSize.height * newScale
        )
        // Anchor bottom-center so scaling feels grounded
        let newOrigin = CGPoint(
            x: oldFrame.midX - newSize.width * 0.5,
            y: oldFrame.minY
        )
        setFrame(CGRect(origin: newOrigin, size: newSize), display: true)
        UserDefaults.standard.set(Double(newOrigin.x), forKey: "KuroCat.PosX")
        UserDefaults.standard.set(Double(newOrigin.y), forKey: "KuroCat.PosY")
    }

    func resetPosition() {
        let origin = OverlayWindow.defaultOrigin(for: frame.size)
        setFrameOrigin(origin)
        UserDefaults.standard.set(Double(origin.x), forKey: "KuroCat.PosX")
        UserDefaults.standard.set(Double(origin.y), forKey: "KuroCat.PosY")
    }

    private static func initialOrigin(for size: CGSize) -> CGPoint {
        let d = UserDefaults.standard
        if d.object(forKey: "KuroCat.PosX") != nil && d.object(forKey: "KuroCat.PosY") != nil {
            let x = CGFloat(d.double(forKey: "KuroCat.PosX"))
            let y = CGFloat(d.double(forKey: "KuroCat.PosY"))
            let saved = CGPoint(x: x, y: y)
            // Ensure saved origin is still on a connected display
            let rect = CGRect(origin: saved, size: size)
            if NSScreen.screens.contains(where: { $0.frame.intersects(rect) }) {
                return saved
            }
        }
        return defaultOrigin(for: size)
    }

    private static func defaultOrigin(for size: CGSize) -> CGPoint {
        let screen = NSScreen.main?.visibleFrame ?? CGRect(x: 0, y: 0, width: 1440, height: 900)
        return CGPoint(
            x: screen.maxX - size.width - 28,
            y: screen.minY + 18
        )
    }
}

// MARK: - 「换装间」 skin import window (warm cream card UI shared with Windows/Linux)

private enum DressingPalette {
    static let background = NSColor(calibratedRed: 0.984, green: 0.969, blue: 0.941, alpha: 1)   // #FBF7F0
    static let card = NSColor(calibratedRed: 0.953, green: 0.914, blue: 0.863, alpha: 1)         // #F3E9DC
    static let ink = NSColor(calibratedRed: 0.231, green: 0.184, blue: 0.165, alpha: 1)          // #3B2F2A
    static let brown = NSColor(calibratedRed: 0.353, green: 0.290, blue: 0.251, alpha: 1)        // #5A4A40
    static let muted = NSColor(calibratedRed: 0.659, green: 0.600, blue: 0.553, alpha: 1)        // #A8998D
    static let orange = NSColor(calibratedRed: 0.910, green: 0.588, blue: 0.306, alpha: 1)       // #E8964E
    static let orangeDown = NSColor(calibratedRed: 0.843, green: 0.518, blue: 0.243, alpha: 1)   // #D7843E
    static let dash = NSColor(calibratedRed: 0.890, green: 0.765, blue: 0.627, alpha: 1)         // #E3C3A0
    static let zone = NSColor(calibratedRed: 1.0, green: 0.992, blue: 0.976, alpha: 1)           // #FFFDF9
    static let zoneHover = NSColor(calibratedRed: 1.0, green: 0.945, blue: 0.886, alpha: 1)      // #FFF1E2
    static let ok = NSColor(calibratedRed: 0.243, green: 0.557, blue: 0.353, alpha: 1)           // #3E8E5A
    static let err = NSColor(calibratedRed: 0.761, green: 0.286, blue: 0.231, alpha: 1)          // #C2493B
    static let note = NSColor(calibratedRed: 0.541, green: 0.482, blue: 0.439, alpha: 1)         // #8A7B70
    static let footer = NSColor(calibratedRed: 0.702, green: 0.651, blue: 0.608, alpha: 1)       // #B3A69B
}

private final class FlippedView: NSView {
    override var isFlipped: Bool { true }
}

/// Live preview of the skin being worn, drawn by the real renderer into a rounded card.
private final class SkinPreviewView: NSView {
    private let pose = CatPhysics()
    override var isFlipped: Bool { true }
    override func draw(_ dirtyRect: NSRect) {
        guard let ctx = NSGraphicsContext.current?.cgContext else { return }
        let card = NSBezierPath(roundedRect: bounds.insetBy(dx: 0.5, dy: 0.5), xRadius: 18, yRadius: 18)
        DressingPalette.card.setFill()
        card.fill()
        card.addClip()
        ctx.saveGState()
        ctx.scaleBy(x: bounds.width / 290, y: bounds.height / 260)
        ctx.translateBy(x: -40, y: -36)
        CatRenderer.draw(in: ctx, physics: pose, showPermissionPill: false, isPreview: true)
        ctx.restoreGState()
    }
}

/// Dashed drop zone of the 「换装间」 window; click it to pick a file.
final class SkinDropView: NSView {
    var onFiles: (([URL]) -> Void)?
    var onClick: (() -> Void)?
    private var highlighted = false { didSet { needsDisplay = true } }
    override var isFlipped: Bool { true }

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        registerForDraggedTypes([.fileURL])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    static func fileURLs(from info: NSDraggingInfo, kurocatOnly: Bool) -> [URL] {
        let objects = info.draggingPasteboard.readObjects(forClasses: [NSURL.self], options: [.urlReadingFileURLsOnly: true])
        let urls = (objects as? [URL]) ?? []
        if !kurocatOnly { return urls }
        return urls.filter { url in
            let ext = url.pathExtension.lowercased()
            return ext == "kurocat" || ext == "kurokb" || (ext == "json" && KeyboardSkinSpec.looksLikeKeyboardJSON(url))
        }
    }

    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation {
        let ok = !SkinDropView.fileURLs(from: sender, kurocatOnly: false).isEmpty
        highlighted = ok
        return ok ? .copy : []
    }

    override func draggingExited(_ sender: NSDraggingInfo?) {
        highlighted = false
    }

    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        highlighted = false
        let urls = SkinDropView.fileURLs(from: sender, kurocatOnly: false)
        guard !urls.isEmpty else { return false }
        DispatchQueue.main.async { [weak self] in self?.onFiles?(urls) }
        return true
    }

    override func mouseDown(with event: NSEvent) {
        // Claim the click so the matching mouseUp comes back to this view.
    }

    override func mouseUp(with event: NSEvent) {
        if bounds.contains(convert(event.locationInWindow, from: nil)) { onClick?() }
    }

    override func resetCursorRects() {
        addCursorRect(bounds, cursor: .pointingHand)
    }

    override func draw(_ dirtyRect: NSRect) {
        let box = NSBezierPath(roundedRect: bounds.insetBy(dx: 1.5, dy: 1.5), xRadius: 16, yRadius: 16)
        (highlighted ? DressingPalette.zoneHover : DressingPalette.zone).setFill()
        box.fill()
        box.lineWidth = highlighted ? 2.4 : 2
        if !highlighted {
            let dash: [CGFloat] = [7, 5]
            box.setLineDash(dash, count: dash.count, phase: 0)
        }
        (highlighted ? DressingPalette.orange : DressingPalette.dash).setStroke()
        box.stroke()

        // Paw print
        let k: CGFloat = highlighted ? 1.15 : 1
        let c = CGPoint(x: bounds.midX, y: bounds.midY - 26)
        DressingPalette.orange.withAlphaComponent(highlighted ? 1 : 0.85).setFill()
        NSBezierPath(ovalIn: NSRect(x: c.x - 9.5 * k, y: c.y + (6 - 7.8) * k, width: 19 * k, height: 15.6 * k)).fill()
        for (tx, ty) in [(-10.5, -5.5), (-3.8, -11.5), (3.8, -11.5), (10.5, -5.5)] as [(CGFloat, CGFloat)] {
            NSBezierPath(ovalIn: NSRect(x: c.x + (tx - 3.7) * k, y: c.y + (ty - 4.4) * k, width: 7.4 * k, height: 8.8 * k)).fill()
        }

        func centered(_ string: String, font: NSFont, color: NSColor, y: CGFloat) {
            let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color]
            let size = (string as NSString).size(withAttributes: attrs)
            (string as NSString).draw(at: NSPoint(x: bounds.midX - size.width / 2, y: y), withAttributes: attrs)
        }
        centered(highlighted ? "松手就换上啦" : "把 .kurocat 皮肤拖到这里", font: .systemFont(ofSize: 15, weight: .bold),
                 color: DressingPalette.brown, y: bounds.midY + 2)
        centered("也可以直接拖到桌面上的小猫身上 · 点这里选择文件", font: .systemFont(ofSize: 11.5),
                 color: DressingPalette.note, y: bounds.midY + 28)
    }
}

/// Orange pill button.
private final class PillButton: NSButton {
    override func draw(_ dirtyRect: NSRect) {
        let pill = NSBezierPath(roundedRect: bounds.insetBy(dx: 1, dy: 1), xRadius: (bounds.height - 2) / 2, yRadius: (bounds.height - 2) / 2)
        (isHighlighted ? DressingPalette.orangeDown : DressingPalette.orange).setFill()
        pill.fill()
        let attrs: [NSAttributedString.Key: Any] = [.font: NSFont.systemFont(ofSize: 14.5, weight: .bold), .foregroundColor: NSColor.white]
        let size = (title as NSString).size(withAttributes: attrs)
        (title as NSString).draw(at: NSPoint(x: bounds.midX - size.width / 2, y: bounds.midY - size.height / 2), withAttributes: attrs)
    }
    override func resetCursorRects() {
        addCursorRect(bounds, cursor: .pointingHand)
    }
}

/// 「换装间」: import `.kurocat` skins with drag & drop or a file picker.
final class DressingRoomWindowController: NSWindowController {
    var onImport: ((URL) -> Void)?
    private let preview = SkinPreviewView(frame: NSRect(x: 22, y: 22, width: 150, height: 134))
    private let nameLabel = NSTextField(labelWithString: "")
    private let authorLabel = NSTextField(labelWithString: "")
    private let statusLabel = NSTextField(wrappingLabelWithString: "")

    init() {
        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 444, height: 472),
                              styleMask: [.titled, .closable], backing: .buffered, defer: false)
        window.title = "换装间"
        window.isReleasedWhenClosed = false
        window.level = .floating
        window.titlebarAppearsTransparent = true
        window.backgroundColor = DressingPalette.background
        window.appearance = NSAppearance(named: .aqua)
        super.init(window: window)

        let content = FlippedView(frame: NSRect(x: 0, y: 0, width: 444, height: 472))
        func label(_ text: String, _ font: NSFont, _ color: NSColor, _ frame: NSRect, wraps: Bool = false) -> NSTextField {
            let field = wraps ? NSTextField(wrappingLabelWithString: text) : NSTextField(labelWithString: text)
            field.font = font
            field.textColor = color
            field.frame = frame
            return field
        }
        content.addSubview(preview)
        content.addSubview(label("换装间", .systemFont(ofSize: 21, weight: .heavy), DressingPalette.ink, NSRect(x: 190, y: 22, width: 240, height: 30)))
        content.addSubview(label("正在穿", .systemFont(ofSize: 11.5), DressingPalette.muted, NSRect(x: 191, y: 58, width: 230, height: 16)))
        nameLabel.font = .systemFont(ofSize: 15, weight: .bold)
        nameLabel.textColor = DressingPalette.brown
        nameLabel.lineBreakMode = .byTruncatingTail
        nameLabel.frame = NSRect(x: 190, y: 74, width: 236, height: 22)
        authorLabel.font = .systemFont(ofSize: 11.5)
        authorLabel.textColor = DressingPalette.muted
        authorLabel.lineBreakMode = .byTruncatingTail
        authorLabel.frame = NSRect(x: 191, y: 97, width: 232, height: 16)
        content.addSubview(nameLabel)
        content.addSubview(authorLabel)
        let hint = label("导入皮肤工坊做好的 .kurocat 文件，\n小猫会立刻换上新毛色。", .systemFont(ofSize: 11.5), DressingPalette.muted,
                         NSRect(x: 191, y: 120, width: 236, height: 36), wraps: true)
        content.addSubview(hint)

        let drop = SkinDropView(frame: NSRect(x: 22, y: 172, width: 400, height: 150))
        drop.onFiles = { [weak self] urls in urls.forEach { self?.onImport?($0) } }
        drop.onClick = { [weak self] in self?.chooseFile() }
        content.addSubview(drop)

        let button = PillButton(title: "选择文件…", target: self, action: #selector(chooseFile))
        button.isBordered = false
        button.frame = NSRect(x: 147, y: 338, width: 150, height: 40)
        content.addSubview(button)

        statusLabel.alignment = .center
        statusLabel.font = .systemFont(ofSize: 12.5)
        statusLabel.frame = NSRect(x: 22, y: 390, width: 400, height: 40)
        content.addSubview(statusLabel)

        let footerPath = (SkinLibrary.directory.path as NSString).abbreviatingWithTildeInPath
        let footer = label("皮肤独立保存在 \(footerPath)（软件更新会自动保留）  ·  右键小猫 → 猫咪皮肤 可切换或备份", .systemFont(ofSize: 10.5),
                           DressingPalette.footer, NSRect(x: 22, y: 434, width: 400, height: 34), wraps: true)
        footer.alignment = .center
        content.addSubview(footer)

        window.contentView = content
        window.center()
        setStatus("支持拖入多个文件；坏掉的文件会告诉你哪里不对。", kind: 0)
        refresh()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    /// kind: 0 neutral, 1 success, 2 error
    func setStatus(_ text: String, kind: Int) {
        statusLabel.stringValue = text
        statusLabel.textColor = kind == 1 ? DressingPalette.ok : (kind == 2 ? DressingPalette.err : DressingPalette.note)
        statusLabel.font = .systemFont(ofSize: 12.5, weight: kind == 0 ? .regular : .semibold)
    }

    /// Re-reads the worn skin (name, author, live preview).
    func refresh() {
        let skin = CatSettings.shared.activeSkin
        nameLabel.stringValue = skin.name
        authorLabel.stringValue = skin.author.isEmpty ? "" : "作者 \(skin.author)"
        preview.needsDisplay = true
    }

    var isVisible: Bool { window?.isVisible ?? false }

    func present() {
        refresh()
        NSApp.activate(ignoringOtherApps: true)
        showWindow(nil)
        window?.makeKeyAndOrderFront(nil)
    }

    @objc private func chooseFile() {
        guard let window else { return }
        let panel = NSOpenPanel()
        panel.title = "选择 .kurocat 皮肤文件"
        panel.prompt = "导入"
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = true
        panel.allowedContentTypes = [UTType(filenameExtension: "kurocat") ?? .data]
        panel.beginSheetModal(for: window) { [weak self] response in
            guard response == .OK else { return }
            for url in panel.urls { self?.onImport?(url) }
        }
    }
}

// MARK: - Unified Native Settings Window (System Light/Dark Adaptive)

private final class SettingsCardView: NSView {
    override var isFlipped: Bool { true }
    override func draw(_ dirtyRect: NSRect) {
        let rect = bounds.insetBy(dx: 0.5, dy: 0.5)
        let path = NSBezierPath(roundedRect: rect, xRadius: 12, yRadius: 12)
        NSColor.controlBackgroundColor.setFill()
        path.fill()
        NSColor.separatorColor.withAlphaComponent(0.55).setStroke()
        path.lineWidth = 1.0
        path.stroke()
    }
}

/// Consolidated native macOS Settings window grouping Appearance, Interaction, and Window/System controls.
final class SettingsWindowController: NSWindowController {
    var onSettingsChanged: (() -> Void)?
    var onScaleChanged: ((CGFloat) -> Void)?
    var onResetPoseAndPosition: (() -> Void)?
    var onOpenDressingRoom: (() -> Void)?
    var onImportKeyboardSkin: (() -> Void)?
    var onApplyWindowLevel: (() -> Void)?
    var onApplyOBSMode: (() -> Void)?
    var onAutoHideChanged: (() -> Void)?
    var getAutoStart: (() -> Bool)?
    var setAutoStart: ((Bool) -> Void)?
    var onLanguageChanged: (() -> Void)?

    private var skinPopup: NSPopUpButton!
    private var kbPopup: NSPopUpButton!
    private var eyePopup: NSPopUpButton!
    private var tabletPopup: NSPopUpButton!
    private var obsPopup: NSPopUpButton!
    private var langSeg: NSSegmentedControl!

    private var whiteOutlineSwitch: NSSwitch!
    private var flipSwitch: NSSwitch!
    private var angerSwitch: NSSwitch!
    private var workAutoTypingSwitch:NSSwitch!
    private var workKeyBadgesSwitch:NSSwitch!
    private var workRandomExpressionsSwitch:NSSwitch!
    private var workSoundSwitch:NSSwitch!
    private var workKeyboardSoundPopup:NSPopUpButton!
    private var workPopSoundSwitch:NSSwitch!
    private var workPopVolumeSlider:NSSlider!
    private var workPopVolumeLabel:NSTextField!
    private var workKeyVolumeSlider:NSSlider!
    private var workMeowVolumeSlider:NSSlider!
    private var workKeyVolumeLabel:NSTextField!
    private var workMeowVolumeLabel:NSTextField!
    private var badgesSwitch: NSSwitch!
    private var legendsSwitch: NSSwitch!
    private var fullscreenOverlaySwitch: NSSwitch!
    private var clickThroughSwitch: NSSwitch!
    private var autoHideSwitch: NSSwitch!
    private var obsHideSwitch: NSSwitch!
    private var autoStartSwitch: NSSwitch!

    private var rotSlider: NSSlider!
    private var rotValLabel: NSTextField!
    private var scaleSlider: NSSlider!
    private var scaleValLabel: NSTextField!

    private var skinIds: [String] = []
    private var kbIds: [String] = []

    init() {
        let win = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 492, height: 610),
            styleMask: [.titled, .closable],
            backing: .buffered,
            defer: false
        )
        win.isReleasedWhenClosed = false
        win.level = .floating
        win.titlebarAppearsTransparent = false
        win.backgroundColor = .windowBackgroundColor
        super.init(window: win)
        rebuildUI()
        win.center()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func tr(_ zh: String, _ en: String) -> String {
        CatSettings.shared.isEnglish ? en : zh
    }

    func present() {
        rebuildUI()
        NSApp.activate(ignoringOtherApps: true)
        showWindow(nil)
        window?.makeKeyAndOrderFront(nil)
    }

    func refresh() {
        guard window?.isVisible == true else { return }
        rebuildUI()
    }

    private func rebuildUI() {
        guard let win = window else { return }
        let s = CatSettings.shared
        win.title = tr("KuroCatWork 设置", "KuroCatWork Settings")

        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 492, height: 610))
        scroll.hasVerticalScroller = true
        scroll.drawsBackground = false
        scroll.borderType = .noBorder

        let doc = FlippedView(frame: NSRect(x: 0, y: 0, width: 492, height: 760))
        let padX: CGFloat = 18
        let cardW: CGFloat = 456
        var y: CGFloat = 14

        func addSectionHeader(_ text: String) {
            let lbl = NSTextField(labelWithString: text)
            lbl.font = .systemFont(ofSize: 12, weight: .semibold)
            lbl.textColor = .secondaryLabelColor
            lbl.frame = NSRect(x: padX + 6, y: y, width: cardW - 12, height: 18)
            doc.addSubview(lbl)
            y += 22
        }

        func addCard(rows: Int, rowH: CGFloat = 36, builder: (NSView, CGFloat) -> Void) {
            let h = CGFloat(rows) * rowH + 8
            let card = SettingsCardView(frame: NSRect(x: padX, y: y, width: cardW, height: h))
            builder(card, rowH)
            doc.addSubview(card)
            y += h + 14
        }

        func addRowDivider(_ card: NSView, yPos: CGFloat) {
            let div = NSBox(frame: NSRect(x: 14, y: yPos, width: cardW - 28, height: 1))
            div.boxType = .separator
            card.addSubview(div)
        }

        func makeLabel(_ text: String, yPos: CGFloat, width: CGFloat = 240) -> NSTextField {
            let lbl = NSTextField(labelWithString: text)
            lbl.font = .systemFont(ofSize: 13)
            lbl.textColor = .labelColor
            lbl.frame = NSRect(x: 14, y: yPos + 8, width: width, height: 20)
            return lbl
        }

        func makeSwitch(_ on: Bool, action: Selector, yPos: CGFloat) -> NSSwitch {
            let sw = NSSwitch()
            sw.state = on ? .on : .off
            sw.target = self
            sw.action = action
            sw.controlSize = .small
            sw.sizeToFit()
            sw.frame = NSRect(x: cardW - 14 - sw.frame.width, y: yPos + (36 - sw.frame.height) * 0.5, width: sw.frame.width, height: sw.frame.height)
            return sw
        }

        // MARK: Card 1 — Appearance & Orientation
        addSectionHeader(tr("外观与方向", "Appearance & Orientation"))
        addCard(rows: 7) { card, rh in
            // Row 0: Cat Skin + Dressing Room button
            card.addSubview(makeLabel(tr("猫咪皮肤", "Cat Skin"), yPos: 4, width: 110))
            skinPopup = NSPopUpButton(frame: NSRect(x: 130, y: 9, width: 222, height: 24), pullsDown: false)
            skinIds = []
            for coat in CatCoatTheme.allCases {
                skinPopup.addItem(withTitle: s.isEnglish ? englishCoatName(coat) : coat.rawValue)
                skinIds.append("coat:\(coat.rawValue)")
            }
            for sk in SkinLibrary.shared.skins {
                skinPopup.addItem(withTitle: sk.name)
                skinIds.append("custom:\(sk.id)")
            }
            if !s.customSkin.isEmpty, let idx = skinIds.firstIndex(of: "custom:\(s.customSkin)") {
                skinPopup.selectItem(at: idx)
            } else if let idx = skinIds.firstIndex(of: "coat:\(s.coatTheme.rawValue)") {
                skinPopup.selectItem(at: idx)
            }
            skinPopup.target = self
            skinPopup.action = #selector(onSkinSelected)
            card.addSubview(skinPopup)

            let dressBtn = NSButton(title: tr("换装间…", "Skins…"), target: self, action: #selector(onTapDressingRoom))
            dressBtn.bezelStyle = .rounded
            dressBtn.controlSize = .small
            dressBtn.frame = NSRect(x: 358, y: 10, width: 84, height: 22)
            card.addSubview(dressBtn)
            addRowDivider(card, yPos: 4 + rh)

            // Row 1: Keyboard Theme + Import button
            let r1 = 4 + rh
            card.addSubview(makeLabel(tr("键盘配色", "Keyboard Theme"), yPos: r1, width: 110))
            kbPopup = NSPopUpButton(frame: NSRect(x: 130, y: r1 + 5, width: 222, height: 24), pullsDown: false)
            kbIds = []
            KeyboardSkinLibrary.shared.reload()
            for kb in KeyboardTheme.allCases {
                kbPopup.addItem(withTitle: s.isEnglish ? englishKBName(kb) : kb.rawValue)
                kbIds.append("theme:\(kb.rawValue)")
            }
            for kb in KeyboardSkinLibrary.shared.skins {
                kbPopup.addItem(withTitle: kb.name)
                kbIds.append("custom:\(kb.id)")
            }
            if !s.customKeyboard.isEmpty, let idx = kbIds.firstIndex(of: "custom:\(s.customKeyboard)") {
                kbPopup.selectItem(at: idx)
            } else if let idx = kbIds.firstIndex(of: "theme:\(s.keyboardTheme.rawValue)") {
                kbPopup.selectItem(at: idx)
            }
            kbPopup.target = self
            kbPopup.action = #selector(onKBSelected)
            card.addSubview(kbPopup)

            let kbBtn = NSButton(title: tr("导入…", "Import…"), target: self, action: #selector(onTapImportKB))
            kbBtn.bezelStyle = .rounded
            kbBtn.controlSize = .small
            kbBtn.frame = NSRect(x: 358, y: r1 + 6, width: 84, height: 22)
            card.addSubview(kbBtn)
            addRowDivider(card, yPos: r1 + rh)

            // Row 2: Eye Color
            let r2 = 4 + rh * 2
            card.addSubview(makeLabel(tr("瞳色切换", "Eye Color"), yPos: r2, width: 110))
            eyePopup = NSPopUpButton(frame: NSRect(x: 130, y: r2 + 5, width: 312, height: 24), pullsDown: false)
            for eye in EyeColorTheme.allCases {
                eyePopup.addItem(withTitle: s.isEnglish ? englishEyeName(eye) : eye.rawValue)
            }
            if let idx = EyeColorTheme.allCases.firstIndex(of: s.eyeTheme) { eyePopup.selectItem(at: idx) }
            eyePopup.target = self
            eyePopup.action = #selector(onEyeSelected)
            card.addSubview(eyePopup)
            addRowDivider(card, yPos: r2 + rh)

            // Row 3: White Outline toggle
            let r3 = 4 + rh * 3
            card.addSubview(makeLabel(tr("小猫白色外描边（贴纸风）", "White Sticker Outline"), yPos: r3, width: 320))
            whiteOutlineSwitch = makeSwitch(s.whiteOutline, action: #selector(onToggleWhiteOutline), yPos: r3)
            card.addSubview(whiteOutlineSwitch)
            addRowDivider(card, yPos: r3 + rh)

            // Row 4: Horizontal Flip toggle
            let r4 = 4 + rh * 4
            card.addSubview(makeLabel(tr("水平镜像翻转（左右朝向）", "Flip Horizontal"), yPos: r4, width: 320))
            flipSwitch = makeSwitch(s.flipHorizontal, action: #selector(onToggleFlip), yPos: r4)
            card.addSubview(flipSwitch)
            addRowDivider(card, yPos: r4 + rh)

            // Row 5: Rotation Angle slider + Reset 0°
            let r5 = 4 + rh * 5
            card.addSubview(makeLabel(tr("旋转方向", "Rotation"), yPos: r5, width: 96))
            rotSlider = NSSlider(value: Double(s.rotationDeg), minValue: -180, maxValue: 180, target: self, action: #selector(onRotationChanged))
            rotSlider.frame = NSRect(x: 112, y: r5 + 8, width: 204, height: 20)
            card.addSubview(rotSlider)
            rotValLabel = NSTextField(labelWithString: "\(Int(s.rotationDeg.rounded()))°")
            rotValLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .medium)
            rotValLabel.textColor = .secondaryLabelColor
            rotValLabel.alignment = .right
            rotValLabel.frame = NSRect(x: 320, y: r5 + 9, width: 42, height: 18)
            card.addSubview(rotValLabel)
            let zeroBtn = NSButton(title: tr("回正", "0°"), target: self, action: #selector(onResetRotation))
            zeroBtn.bezelStyle = .rounded
            zeroBtn.controlSize = .small
            zeroBtn.frame = NSRect(x: 368, y: r5 + 7, width: 74, height: 22)
            card.addSubview(zeroBtn)
            addRowDivider(card, yPos: r5 + rh)

            // Row 6: Scale slider + Reset Pose & Position
            let r6 = 4 + rh * 6
            card.addSubview(makeLabel(tr("桌宠大小", "Scale"), yPos: r6, width: 96))
            scaleSlider = NSSlider(value: Double(s.scale), minValue: 0.45, maxValue: 2.0, target: self, action: #selector(onScaleSliderChanged))
            scaleSlider.frame = NSRect(x: 112, y: r6 + 8, width: 204, height: 20)
            card.addSubview(scaleSlider)
            scaleValLabel = NSTextField(labelWithString: "\(Int((s.scale * 100).rounded()))%")
            scaleValLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .medium)
            scaleValLabel.textColor = .secondaryLabelColor
            scaleValLabel.alignment = .right
            scaleValLabel.frame = NSRect(x: 320, y: r6 + 9, width: 42, height: 18)
            card.addSubview(scaleValLabel)
            let resetAllBtn = NSButton(title: tr("重置位置", "Reset"), target: self, action: #selector(onTapResetPose))
            resetAllBtn.bezelStyle = .rounded
            resetAllBtn.controlSize = .small
            resetAllBtn.frame = NSRect(x: 368, y: r6 + 7, width: 74, height: 22)
            card.addSubview(resetAllBtn)
        }

        // MARK: Card 2 — Interaction & Effects
        addSectionHeader(tr("互动与特效", "Interaction & Effects"))
        addCard(rows: 4) { card, rh in
            // Row 0: Fast-typing anger toggle
            card.addSubview(makeLabel(tr("打字过快时生气表情", "Angry Expression on Fast Typing"), yPos: 4, width: 320))
            angerSwitch = makeSwitch(s.enableAnger, action: #selector(onToggleAnger), yPos: 4)
            card.addSubview(angerSwitch)
            addRowDivider(card, yPos: 4 + rh)

            // Row 1: Key badges
            let r1 = 4 + rh
            card.addSubview(makeLabel(tr("显示按键气泡 ([S] [W] [⇧])", "Show Key & Click Badges"), yPos: r1, width: 320))
            badgesSwitch = makeSwitch(s.showKeyBadges, action: #selector(onToggleBadges), yPos: r1)
            card.addSubview(badgesSwitch)
            addRowDivider(card, yPos: r1 + rh)

            // Row 2: Key legends
            let r2 = 4 + rh * 2
            card.addSubview(makeLabel(tr("显示键盘字符", "Show Keycap Legends"), yPos: r2, width: 320))
            legendsSwitch = makeSwitch(s.showKeyLegends, action: #selector(onToggleLegends), yPos: r2)
            card.addSubview(legendsSwitch)
            addRowDivider(card, yPos: r2 + rh)

            // Row 3: Tablet & Stylus. RGB marquee follows work mode exclusively.
            let r4 = 4 + rh * 3
            card.addSubview(makeLabel(tr("数位板与触控笔", "Tablet & Stylus"), yPos: r4, width: 130))
            tabletPopup = NSPopUpButton(frame: NSRect(x: 150, y: r4 + 5, width: 292, height: 24), pullsDown: false)
            tabletPopup.addItems(withTitles: [
                tr("自动检测（连接数位板时切换）", "Auto-Detect When Connected"),
                tr("始终显示数位板与触控笔", "Always Show Tablet & Stylus"),
                tr("始终显示鼠标", "Always Show Mouse")
            ])
            tabletPopup.selectItem(at: max(0, min(2, s.tabletMode)))
            tabletPopup.target = self
            tabletPopup.action = #selector(onTabletSelected)
            card.addSubview(tabletPopup)
        }

        // Work-mode animation preference is independent of expressions and real input.
        addSectionHeader(tr("工作模式", "Work Mode"))
        addCard(rows:10) {card,rh in
            card.addSubview(makeLabel(tr("有运行任务时自主打字动画", "Autonomous Typing for Running Tasks"),yPos:4,width:330))
            workAutoTypingSwitch=makeSwitch(s.workAutoTyping,action:#selector(onToggleWorkAutoTyping),yPos:4)
            card.addSubview(workAutoTypingSwitch)
            addRowDivider(card,yPos:4+rh)
            let explanation=makeLabel(tr("仅关闭持续打字，生成工作条与表情仍保留", "Continuous typing only; new bars and expressions stay"),yPos:4+rh,width:420)
            explanation.font = .systemFont(ofSize:11);explanation.textColor = .secondaryLabelColor
            card.addSubview(explanation)
            addRowDivider(card,yPos:4+rh*2)
            card.addSubview(makeLabel(tr("自主打字随机表情", "Random Working Expressions"),yPos:4+rh*2,width:330))
            workRandomExpressionsSwitch=makeSwitch(WorkModeExperience.shared.emotionsEnabled,action:#selector(onToggleWorkRandomExpressions),yPos:4+rh*2)
            workRandomExpressionsSwitch.identifier=NSUserInterfaceItemIdentifier("workRandomExpressions")
            workRandomExpressionsSwitch.toolTip=tr("控制随机生气／眩晕；不影响等待处理提醒和甩动眩晕", "Random anger/dizziness only; waiting reminders and shake dizziness stay")
            card.addSubview(workRandomExpressionsSwitch)
            addRowDivider(card,yPos:4+rh*3)
            card.addSubview(makeLabel(tr("显示键盘气泡", "Show Keyboard Bubbles"),yPos:4+rh*3,width:330))
            workKeyBadgesSwitch=makeSwitch(s.workKeyBadges,action:#selector(onToggleWorkKeyBadges),yPos:4+rh*3)
            workKeyBadgesSwitch.identifier=NSUserInterfaceItemIdentifier("workKeyBadges")
            card.addSubview(workKeyBadgesSwitch)
            addRowDivider(card,yPos:4+rh*4)
            card.addSubview(makeLabel(tr("开启声音（仅工作模式）", "Enable Sound (Work Mode Only)"),yPos:4+rh*4,width:330))
            workSoundSwitch=makeSwitch(WorkModeExperience.shared.soundEnabled,action:#selector(onToggleWorkSound),yPos:4+rh*4)
            workSoundSwitch.identifier=NSUserInterfaceItemIdentifier("workSoundEnabled")
            card.addSubview(workSoundSwitch)
            addRowDivider(card,yPos:4+rh*5)
            func volumeRow(_ title:String,_ value:Double,_ row:Int,_ action:Selector,_ identifier:String)->(NSSlider,NSTextField) {
                let y=4+rh*CGFloat(row)
                card.addSubview(makeLabel(title,yPos:y,width:148))
                let slider=NSSlider(value:value,minValue:0,maxValue:1,target:self,action:action)
                slider.frame=NSRect(x:164,y:y+7,width:214,height:22)
                slider.isContinuous=true;slider.identifier=NSUserInterfaceItemIdentifier(identifier)
                slider.setAccessibilityLabel(title)
                let valueLabel=makeLabel("\(Int((value*100).rounded()))%",yPos:y,width:55)
                valueLabel.frame.origin.x=386;valueLabel.alignment = .right
                card.addSubview(slider);card.addSubview(valueLabel)
                return (slider,valueLabel)
            }
            card.addSubview(makeLabel(tr("键盘音色", "Keyboard Sound"),yPos:4+rh*5,width:148))
            workKeyboardSoundPopup=NSPopUpButton(frame:NSRect(x:164,y:4+rh*5+5,width:276,height:26),pullsDown:false)
            workKeyboardSoundPopup.identifier=NSUserInterfaceItemIdentifier("workKeyboardSound")
            workKeyboardSoundPopup.addItems(withTitles:WorkKeyboardSound.allCases.map{$0.title})
            workKeyboardSoundPopup.selectItem(at:WorkKeyboardSound.allCases.firstIndex(of:WorkSounds.shared.keyboardStyle) ?? 0)
            workKeyboardSoundPopup.target=self;workKeyboardSoundPopup.action=#selector(onWorkKeyboardSoundChanged)
            card.addSubview(workKeyboardSoundPopup)
            addRowDivider(card,yPos:4+rh*6)
            (workKeyVolumeSlider,workKeyVolumeLabel)=volumeRow(tr("按键音量", "Keyboard Volume"),WorkSounds.shared.keyboardVolume,6,#selector(onWorkKeyVolumeChanged),"workKeyVolume")
            addRowDivider(card,yPos:4+rh*7)
            (workMeowVolumeSlider,workMeowVolumeLabel)=volumeRow(tr("喵叫音量", "Meow Volume"),WorkSounds.shared.meowVolume,7,#selector(onWorkMeowVolumeChanged),"workMeowVolume")
            addRowDivider(card,yPos:4+rh*8)
            card.addSubview(makeLabel(tr("状态条／任务条弹出音效", "Quota / Task Bubble Sounds"),yPos:4+rh*8,width:330))
            workPopSoundSwitch=makeSwitch(WorkSounds.shared.popEnabled,action:#selector(onToggleWorkPopSound),yPos:4+rh*8)
            workPopSoundSwitch.identifier=NSUserInterfaceItemIdentifier("workPopSoundEnabled")
            card.addSubview(workPopSoundSwitch)
            addRowDivider(card,yPos:4+rh*9)
            (workPopVolumeSlider,workPopVolumeLabel)=volumeRow(tr("弹出音量", "Bubble Volume"),WorkSounds.shared.popVolume,9,#selector(onWorkPopVolumeChanged),"workPopVolume")
        }

        // MARK: Card 3 — Window & System
        addSectionHeader(tr("窗口与系统", "Window & System"))
        addCard(rows: 7) { card, rh in
            // Row 0: Fullscreen topmost
            card.addSubview(makeLabel(tr("全屏游戏/应用置顶显示", "Always On Top Over Fullscreen"), yPos: 4, width: 320))
            fullscreenOverlaySwitch = makeSwitch(s.fullScreenOverlay, action: #selector(onToggleFullscreenOverlay), yPos: 4)
            card.addSubview(fullscreenOverlaySwitch)
            addRowDivider(card, yPos: 4 + rh)

            // Row 1: Full click-through
            let r1 = 4 + rh
            card.addSubview(makeLabel(tr("完全鼠标穿透（按住 ⌥Option 临时拖动）", "Full Click-Through (Hold ⌥Option)"), yPos: r1, width: 340))
            clickThroughSwitch = makeSwitch(s.fullClickThrough, action: #selector(onToggleClickThrough), yPos: r1)
            card.addSubview(clickThroughSwitch)
            addRowDivider(card, yPos: r1 + rh)

            // Row 2: Auto-hide in fullscreen
            let r2 = 4 + rh * 2
            card.addSubview(makeLabel(tr("全屏应用时自动隐藏", "Auto-Hide in Fullscreen Apps"), yPos: r2, width: 320))
            autoHideSwitch = makeSwitch(s.autoHideFullscreen, action: #selector(onToggleAutoHide), yPos: r2)
            card.addSubview(autoHideSwitch)
            addRowDivider(card, yPos: r2 + rh)

            // Row 3: OBS Capture Mode
            let r3 = 4 + rh * 3
            card.addSubview(makeLabel(tr("直播捕获模式 (OBS)", "OBS Capture Mode"), yPos: r3, width: 150))
            obsPopup = NSPopUpButton(frame: NSRect(x: 170, y: r3 + 5, width: 272, height: 24), pullsDown: false)
            obsPopup.addItems(withTitles: [
                tr("关闭（正常桌面悬浮）", "Off (Normal Overlay)"),
                tr("OBS 透明窗口捕获", "OBS Transparent Window"),
                tr("OBS 绿幕模式 (#00FF00)", "OBS Green Screen (#00FF00)")
            ])
            obsPopup.selectItem(at: max(0, min(2, s.obsCaptureMode)))
            obsPopup.target = self
            obsPopup.action = #selector(onOBSSelected)
            card.addSubview(obsPopup)
            addRowDivider(card, yPos: r3 + rh)

            // Row 4: OBS Hide Desktop
            let r4 = 4 + rh * 4
            card.addSubview(makeLabel(tr("OBS 后台捕获（隐藏桌面小猫）", "OBS Background Capture (Hide Desktop)"), yPos: r4, width: 320))
            obsHideSwitch = makeSwitch(s.obsHideDesktop, action: #selector(onToggleOBSHide), yPos: r4)
            obsHideSwitch.isEnabled = (s.obsCaptureMode > 0)
            card.addSubview(obsHideSwitch)
            addRowDivider(card, yPos: r4 + rh)

            // Row 5: Launch at Login
            let r5 = 4 + rh * 5
            card.addSubview(makeLabel(tr("开机自动启动", "Launch at Login"), yPos: r5, width: 320))
            autoStartSwitch = makeSwitch(getAutoStart?() ?? false, action: #selector(onToggleAutoStart), yPos: r5)
            card.addSubview(autoStartSwitch)
            addRowDivider(card, yPos: r5 + rh)

            // Row 6: Language
            let r6 = 4 + rh * 6
            card.addSubview(makeLabel("语言 / Language", yPos: r6, width: 180))
            langSeg = NSSegmentedControl(labels: ["简体中文", "English"], trackingMode: .selectOne, target: self, action: #selector(onLangChanged))
            langSeg.selectedSegment = s.isEnglish ? 1 : 0
            langSeg.frame = NSRect(x: cardW - 14 - 166, y: r6 + 6, width: 166, height: 24)
            card.addSubview(langSeg)
        }

        doc.frame = NSRect(x: 0, y: 0, width: 492, height: y + 8)
        scroll.documentView = doc
        win.contentView = scroll
    }

    private func englishCoatName(_ coat: CatCoatTheme) -> String {
        switch coat {
        case .classicBlack: return "Classic Black Cat"
        case .siamese: return "Siamese Cat"
        case .shorthair: return "Silver Tabby Shorthair"
        case .orangeWhite: return "Orange & White Cat"
        }
    }

    private func englishKBName(_ kb: KeyboardTheme) -> String {
        switch kb {
        case .classicMilk: return "Classic Milk White"
        case .midnightHacker: return "Midnight Hacker Black"
        case .retroCream: return "Retro Cream Gray"
        }
    }

    private func englishEyeName(_ eye: EyeColorTheme) -> String {
        switch eye {
        case .neonChartreuse: return "Neon Chartreuse"
        case .siameseBlue: return "Siamese Ice Blue"
        case .warmAmber: return "Warm Amber"
        case .iceCyan: return "Ice Cyan"
        case .softAmber: return "Soft Amber"
        case .referenceHazel: return "Golden Hazel"
        }
    }

    @objc private func onSkinSelected() {
        let idx = skinPopup.indexOfSelectedItem
        guard idx >= 0 && idx < skinIds.count else { return }
        let token = skinIds[idx]
        if token.hasPrefix("custom:") {
            CatSettings.shared.customSkin = String(token.dropFirst(7))
        } else if token.hasPrefix("coat:"), let coat = CatCoatTheme(rawValue: String(token.dropFirst(5))) {
            CatSettings.shared.customSkin = ""
            CatSettings.shared.coatTheme = coat
            switch coat {
            case .classicBlack: CatSettings.shared.eyeTheme = .neonChartreuse
            case .siamese: CatSettings.shared.eyeTheme = .siameseBlue
            case .shorthair: CatSettings.shared.eyeTheme = .referenceHazel
            case .orangeWhite: CatSettings.shared.eyeTheme = .warmAmber
            }
            if let eIdx = EyeColorTheme.allCases.firstIndex(of: CatSettings.shared.eyeTheme) {
                eyePopup.selectItem(at: eIdx)
            }
        }
        onSettingsChanged?()
    }

    @objc private func onKBSelected() {
        let idx = kbPopup.indexOfSelectedItem
        guard idx >= 0 && idx < kbIds.count else { return }
        let token = kbIds[idx]
        if token.hasPrefix("custom:") {
            CatSettings.shared.customKeyboard = String(token.dropFirst(7))
        } else if token.hasPrefix("theme:"), let kb = KeyboardTheme(rawValue: String(token.dropFirst(6))) {
            CatSettings.shared.customKeyboard = ""
            CatSettings.shared.keyboardTheme = kb
        }
        onSettingsChanged?()
    }

    @objc private func onEyeSelected() {
        let idx = eyePopup.indexOfSelectedItem
        guard idx >= 0 && idx < EyeColorTheme.allCases.count else { return }
        CatSettings.shared.eyeTheme = EyeColorTheme.allCases[idx]
        onSettingsChanged?()
    }

    @objc private func onToggleWhiteOutline() {
        CatSettings.shared.whiteOutline = (whiteOutlineSwitch.state == .on)
        onSettingsChanged?()
    }

    @objc private func onToggleFlip() {
        CatSettings.shared.flipHorizontal = (flipSwitch.state == .on)
        UserDefaults.standard.synchronize()
        onSettingsChanged?()
    }

    @objc private func onRotationChanged() {
        var deg = CGFloat(rotSlider.doubleValue)
        for snap in [-180.0, -90.0, 0.0, 90.0, 180.0] as [CGFloat] {
            if abs(deg - snap) < 4.0 { deg = snap; break }
        }
        CatSettings.shared.rotationDeg = deg
        rotValLabel.stringValue = "\(Int(deg.rounded()))°"
        onSettingsChanged?()
    }

    @objc private func onResetRotation() {
        CatSettings.shared.rotationDeg = 0
        rotSlider.doubleValue = 0
        rotValLabel.stringValue = "0°"
        UserDefaults.standard.synchronize()
        onSettingsChanged?()
    }

    @objc private func onScaleSliderChanged() {
        let sc = CGFloat(scaleSlider.doubleValue)
        scaleValLabel.stringValue = "\(Int((sc * 100).rounded()))%"
        onScaleChanged?(sc)
    }

    @objc private func onTapResetPose() {
        CatSettings.shared.rotationDeg = 0
        CatSettings.shared.flipHorizontal = false
        UserDefaults.standard.synchronize()
        onResetPoseAndPosition?()
        rebuildUI()
    }

    @objc private func onTapDressingRoom() { onOpenDressingRoom?() }
    @objc private func onTapImportKB() { onImportKeyboardSkin?() }

    @objc private func onToggleWorkRandomExpressions() {
        WorkModeExperience.shared.setEmotionsEnabled(workRandomExpressionsSwitch.state == .on)
        onSettingsChanged?()
    }
    @objc private func onToggleWorkKeyBadges() {
        CatSettings.shared.workKeyBadges=workKeyBadgesSwitch.state == .on
        onSettingsChanged?()
    }
    @objc private func onToggleWorkSound() {
        WorkModeExperience.shared.setSoundEnabled(workSoundSwitch.state == .on)
        onSettingsChanged?()
    }
    @objc private func onWorkKeyboardSoundChanged() {
        guard WorkKeyboardSound.allCases.indices.contains(workKeyboardSoundPopup.indexOfSelectedItem) else {return}
        WorkSounds.shared.keyboardStyle=WorkKeyboardSound.allCases[workKeyboardSoundPopup.indexOfSelectedItem]
    }
    @objc private func onToggleWorkPopSound() {WorkSounds.shared.popEnabled=workPopSoundSwitch.state == .on}
    @objc private func onWorkPopVolumeChanged() {
        WorkSounds.shared.popVolume=workPopVolumeSlider.doubleValue
        workPopVolumeLabel.stringValue="\(Int((WorkSounds.shared.popVolume*100).rounded()))%"
    }
    @objc private func onWorkKeyVolumeChanged() {
        WorkSounds.shared.keyboardVolume=workKeyVolumeSlider.doubleValue
        workKeyVolumeLabel.stringValue="\(Int((WorkSounds.shared.keyboardVolume*100).rounded()))%"
    }
    @objc private func onWorkMeowVolumeChanged() {
        WorkSounds.shared.meowVolume=workMeowVolumeSlider.doubleValue
        workMeowVolumeLabel.stringValue="\(Int((WorkSounds.shared.meowVolume*100).rounded()))%"
    }
    @objc private func onToggleWorkAutoTyping() {
        CatSettings.shared.workAutoTyping=(workAutoTypingSwitch.state == .on)
        if !CatSettings.shared.workAutoTyping {WorkModeExperience.shared.parent?.catView.physics.clearWorkTypingMemory()}
        onSettingsChanged?()
    }

    @objc private func onToggleAnger() {
        CatSettings.shared.enableAnger = (angerSwitch.state == .on)
        onSettingsChanged?()
    }

    @objc private func onToggleBadges() {
        CatSettings.shared.showKeyBadges = (badgesSwitch.state == .on)
        onSettingsChanged?()
    }

    @objc private func onToggleLegends() {
        CatSettings.shared.showKeyLegends = (legendsSwitch.state == .on)
        onSettingsChanged?()
    }

    @objc private func onTabletSelected() {
        CatSettings.shared.tabletMode = max(0, min(2, tabletPopup.indexOfSelectedItem))
        onSettingsChanged?()
    }

    @objc private func onToggleFullscreenOverlay() {
        CatSettings.shared.fullScreenOverlay = (fullscreenOverlaySwitch.state == .on)
        onApplyWindowLevel?()
    }

    @objc private func onToggleClickThrough() {
        CatSettings.shared.fullClickThrough = (clickThroughSwitch.state == .on)
    }

    @objc private func onToggleAutoHide() {
        CatSettings.shared.autoHideFullscreen = (autoHideSwitch.state == .on)
        onAutoHideChanged?()
    }

    @objc private func onOBSSelected() {
        let mode = max(0, min(2, obsPopup.indexOfSelectedItem))
        CatSettings.shared.obsCaptureMode = mode
        if mode == 0 {
            CatSettings.shared.obsHideDesktop = false
            obsHideSwitch.state = .off
        }
        obsHideSwitch.isEnabled = (mode > 0)
        onApplyOBSMode?()
    }

    @objc private func onToggleOBSHide() {
        CatSettings.shared.obsHideDesktop = (obsHideSwitch.state == .on)
        onApplyOBSMode?()
    }

    @objc private func onToggleAutoStart() {
        setAutoStart?(autoStartSwitch.state == .on)
    }

    @objc private func onLangChanged() {
        CatSettings.shared.language = (langSeg.selectedSegment == 1) ? "en" : "zh"
        onLanguageChanged?()
        rebuildUI()
    }
}
